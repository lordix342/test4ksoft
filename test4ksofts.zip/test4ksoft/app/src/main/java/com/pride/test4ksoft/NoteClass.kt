package com.pride.test4ksoft

class NoteClass (
    var id: String?,
    var title: String?,
    var description : String?,
    var date : String?
    )

