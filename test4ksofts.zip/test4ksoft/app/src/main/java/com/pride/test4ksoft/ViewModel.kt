package com.pride.test4ksoft

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.pride.test4ksoft.db.DbManager
import kotlinx.coroutines.launch

class ViewModel(application: Application): AndroidViewModel(application) {
    private val dbManager = DbManager(application.applicationContext)
    var noteEdit: MutableLiveData<NoteClass> = MutableLiveData()
    var noteList: MutableLiveData<ArrayList<NoteClass>> = MutableLiveData()

    fun getEdit(note:NoteClass) {
        viewModelScope.launch {
            noteEdit.value = note
        }
    }
    fun listNotesDb() {
        viewModelScope.launch {
            dbManager.openDb()
            noteList.value = dbManager.sortDb()
            dbManager.closeDb()
            Log.d("viewmodel", noteList.value.toString())
        }
    }
    fun deleteNote(id: String){
        dbManager.openDb()
        dbManager.deleteNote(id)
        dbManager.closeDb()
        listNotesDb()
    }
    fun insertNote(title: String, description: String, date:String) {
        dbManager.openDb()
        dbManager.insert(title,description,date)
        dbManager.closeDb()
        listNotesDb()
    }
}