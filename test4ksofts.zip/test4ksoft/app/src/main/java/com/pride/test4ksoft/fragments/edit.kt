package com.pride.test4ksoft.fragments

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.pride.test4ksoft.NoteClass
import com.pride.test4ksoft.R
import com.pride.test4ksoft.ViewModel
import com.pride.test4ksoft.databinding.FragmentEditBinding
import com.pride.test4ksoft.db.DbManager
import java.util.*


class edit() : Fragment() {

    lateinit var binding: FragmentEditBinding
    lateinit var dbManager: DbManager
    private val viewModel : ViewModel by activityViewModels()
    private var noteEdit = NoteClass("","","","")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        //для змін тулбар
        setHasOptionsMenu(true)
        (activity as? AppCompatActivity)?.supportActionBar?.title = "Editing"
        (activity as? AppCompatActivity)?.supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding = FragmentEditBinding.inflate(inflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        dbManager = DbManager(requireContext())
        dbManager.openDb()
        viewModel.noteEdit.observe(viewLifecycleOwner) {
                note ->
            Log.d("edit","editNote")
            if (note != null) {
                noteEdit = note
                binding.edtitle.setText(note.title)
                binding.editTextTextMultiLine.setText(note.description)
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater ) {
        menu.findItem(R.id.fab_create).isVisible = false
        menu.findItem(R.id.fab_update).isVisible = true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.fab_update -> {
                update()
            }
            16908332 -> { //backStack
                getActivity()?.onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        dbManager.closeDb()
        (activity as? AppCompatActivity)?.supportActionBar?.title = "Notes"
        (activity as? AppCompatActivity)?.supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    fun update() {
        val c = Calendar.getInstance()
        val hour = c.get(Calendar.HOUR_OF_DAY)
        val minute = c.get(Calendar.MINUTE)
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)
        val newTitle = binding.edtitle.text.toString()
        val newDescription = binding.editTextTextMultiLine.text.toString()
        if ((newTitle == noteEdit.title)&&(newDescription == noteEdit.description)){
            getActivity()?.onBackPressed()
        }   else {
            viewModel.deleteNote(noteEdit.id!!)
            viewModel.insertNote(newTitle,newDescription,"$day - $month - $year   $hour:$minute")
            activity?.supportFragmentManager?.beginTransaction()?.replace(R.id.place_edit, Listnote())?.commit()
            getActivity()?.onBackPressed()
        }

    }
}