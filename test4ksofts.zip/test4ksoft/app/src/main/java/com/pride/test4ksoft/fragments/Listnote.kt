package com.pride.test4ksoft.fragments

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pride.test4ksoft.NoteClass
import com.pride.test4ksoft.R
import com.pride.test4ksoft.ViewModel
import com.pride.test4ksoft.databinding.FragmentListnoteBinding
import com.pride.test4ksoft.db.DbManager
import com.pride.test4ksoft.noteAdapter
import java.util.*


class Listnote() : Fragment() {

    lateinit var binding: FragmentListnoteBinding
    private var adapter = noteAdapter()
    private val viewModel : ViewModel by activityViewModels()

       override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.fab_create) createNote()
        return super.onOptionsItemSelected(item)
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu.findItem(R.id.fab_update).isVisible = false
        menu.findItem(R.id.fab_create).isVisible = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
        (activity as? AppCompatActivity)?.supportActionBar?.title = "Notes"
        (activity as? AppCompatActivity)?.supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentListnoteBinding.inflate(inflater)

        viewModel.listNotesDb()

        viewModel.noteList.observe(viewLifecycleOwner) {
            adapter.setData(it)
            binding.rcView.adapter = adapter
            binding.rcView.layoutManager = LinearLayoutManager(requireContext(),
                RecyclerView.VERTICAL, false)
        }

        adapter.onItemClick = { notes ->
            clickNote(notes)
        }
        return binding.root
    }

    private fun clickNote(note: NoteClass) {
        viewModel.getEdit(note)
        activity?.supportFragmentManager?.beginTransaction()?.
        replace(R.id.list_holder, edit())?.addToBackStack("key1")?.commit()
    }
    private fun createNote() {
        // Дата
        val c = Calendar.getInstance()
        val hour = c.get(Calendar.HOUR_OF_DAY)
        val minute = c.get(Calendar.MINUTE)
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)
        viewModel.insertNote("Нова замітка","","$day - $month - $year   $hour:$minute")

    }
}